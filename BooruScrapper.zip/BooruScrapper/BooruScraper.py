#!/usr/bin/python3
from BooruScraperFunction import *


def main():
    """you can add params to the Setup functions to skip"""
    directory = dirSetup()
    limit = limitSetup()
    defaultURL = urlSetup()
    artist = artistSetup()
    ScrapeFromArtist(defaultURL, artist, directory, limit)


if __name__ == '__main__':
    ti = time.time()
    main()
    print('\n~~~[system] total run time is {} seconds~~~\n'.format(time.time()-ti))

