#!/usr/bin/python
import os
import re
import sys
import time
import shutil
import urllib.error
import urllib.parse
import urllib.request

import numpy as np
from bs4 import BeautifulSoup

'''
This script is compatible with several other image boards
This includes donmai.moe, danbooru.donmai.us, and safebooru.donmai.us
But bewared that some boards are less family-friendly than others
'''


def dirSetup(opt=''):
    directory = ''
    if opt != '':
        print('\nDirectory has been selected\n')
        return opt

    confirmation = False
    while confirmation is False:
        directory = input('Please enter a name for directory (leaving it blank will return as "src"): ')
        if directory == '':
            directory = 'src'
        check = input('\nYou have entered {}. Are you sure? (Y/n)'.format(directory))
        if check in ['Y', 'y', '']:
            confirmation = True

    if directory in os.listdir():
        print('\nDirectory has been selected\n')
        return directory

    os.mkdir(directory)
    print('\nDirectory has been created\n')
    return directory


def limitSetup(opt=-9999):
    limit = 0
    tot, usd, fre = shutil.disk_usage('/')
    freeSpace = int(fre/(10**6))

    if opt != -9999:
        print('\nlimit has been set\n')
        if opt == -1:
            return freeSpace
        return opt

    confirmation = False
    while confirmation is False:
        limit = float(input('Please enter a maximum scraping capacity (-1 will return unlimited capacity) [MB]: '))
        if limit == -1 or limit > freeSpace:
            limit = freeSpace
        check = input('\nYou have allocated {} MB. Are you sure? (Y/n)'.format(limit))
        if check in ['Y', 'y', '']:
            confirmation = True
            print('\nlimit has been set\n')
    return limit


def urlSetup(opt=-1):
    defaultURL = ''
    availableWebsite = {
        0: 'https://donmai.moe',
        1: 'https://danbooru.donmai.us',
        2: 'https://tbib.org/index.php'
    }
    if opt != -1:
        print('\nImage Board has been selected\n')
        return availableWebsite[opt]

    confirmation = False
    while confirmation is False:
        print('TEMP| please note this version does not support Bigbooru, as they follow a completely different conventions for stuff, still tag based, but god I dont want to add new exceptions just for bib')
        inp = input('Which booru do you want to select?\nEnter 0 for Safebooru'
                    '\nEnter 1 for Danbooru\nEnter 2 for Bigbooru\n: ')
        if inp not in ['0', '1', '2']:
            print('Please enter a valid response!\n')
            continue

        defaultURL = availableWebsite[int(inp)]
        inp = input('\nYou have selected {}. Are you sure? (Y/n)'.format(defaultURL))
        if inp in ['Y', 'y', '']:
            confirmation = True
            print('\nImage Board has been selected\n')
    return defaultURL


def artistSetup(opt=''):
    artist = ''
    if opt != '':
        print('\nName is being processing . . .\n')
        return opt

    confirmation = False
    while confirmation is False:
        artist = input('Please enter an artist name (replace " " with "_"): ')
        check = input('\nYou have selected {}. Are you sure? (Y/n)'.format(artist))
        if check in ['Y', 'y', '']:
            confirmation = True
            print('\nName is being processing . . .\n')
    return artist


# ################### Back End Functions ####################
def joinPath(defaultURL, path):
    """join both strings together, that's literally it"""
    return urllib.parse.urljoin(defaultURL, path)


def readURL(url, decode='utf-8', waitTime=0.1):
    """request source page with the provided url, serving as the portal between the internet and the local system"""
    try:
        sourcePage = urllib.request.urlopen(url)
        time.sleep(waitTime)

        if decode == '':
            return BeautifulSoup(sourcePage.read(), 'html.parser')
        return BeautifulSoup(sourcePage.read().decode(decode), 'html.parser')
    except urllib.error.URLError as e:
        print('Error with url {}, reason:'.format(url))
        print(e.reason)
        return sys.exit()


def findHref(soup):
    """find all artwork post hrefs with the provided soup object (single page)"""
    href = []
    for code in soup.find_all('a', class_='post-preview-link'):
        href.append(code['href'])
    return href


def findAllHref(url, tag):
    """find all artwork hrefs with the provided artist tag (several pages)"""
    soup = readURL(url + '?tags=' + tag)
    maxPage = findPage(soup)
    href = np.array([])

    for i in range(maxPage):
        currentPage = str(i+1)

        data = '?page=' + currentPage + '&tags=' + tag  # I tried to avoid this, but I can't get urllib.request.Request() to work
        newSoup = readURL(url+data)
        result = np.array(findHref(newSoup))
        href = np.concatenate((href, result))
    return href


def findArtist(defaultURL, name):
    """find the possible illustrator in the image board given the user input"""
    data = '?commit=Search&search%5Bany_name_matches%5D={}&search%5Border%5D=created_at'.format(name)
    url = joinPath(defaultURL, 'artists')
    soup = readURL(url + data)
    maxPage = findPage(soup)

    if maxPage > 99:
        print('Too many results for findArtist().\nPlease enter a more concise name.')
        exitScript()

    artistList = []
    postList = []
    for i in range(maxPage):
        currentPage = str(i+1)
        data = '?commit=Search&page={}&search%5Bany_name_matches%5D={}&search%5Border%5D=created_at'.format(currentPage, name)
        newSoup = readURL(url+data)
        for artist in newSoup.find_all('tr', class_='h-10'):
            artistList.append(artist.find('a', class_='tag-type-1').get_text())
            postList.append(artist.find('span', class_='post-count').get_text())

    if len(artistList) == 1:
        return artistList[0]
    artistList = np.array(artistList)
    postList = np.array(postList).astype(int)
    return findNextBestMatch(artistList, postList)


def findNextBestMatch(artistList, postList):
    index = postList.argmax()
    inp = input('Best match of your search result is {}.\nDo you want to select this artist? (Y/n)\n'.format(artistList[index]))
    if inp in ['', 'y', 'Y']:
        return artistList[index]

    while inp == 'n':
        index = postList.argmax()
        artistList = np.delete(artistList, index)
        postList = np.delete(postList, index)

        if len(artistList) == 1:
            print('{} is the last artist in your search result!\n'.format(artistList[0]))
            return artistList[0]

        nextArtist = artistList[postList.argmax()]
        inp = input('Your next best match is {}.\nWould you like to select this artist? (Y/n)\n'.format(nextArtist))
        if inp in ['', 'y', 'Y']:
            return nextArtist


def findPage(soup):
    pages = soup.find_all('a', class_='paginator-page')
    pageList = ['1']
    for number in pages:
        pageList.append(number.get_text())
    pageList = np.array(pageList).astype(int)
    return max(pageList)


def saveIMG(directory, name, href, fileLink, pathEnd):
    code = re.findall(r'\d{1,7}', href)[0]
    jpgPath = directory+'/'+name+'_'+code+pathEnd
    urllib.request.urlretrieve(fileLink, jpgPath)
    return


def getFileData(soup):
    data = soup.find('li', id='post-info-size')
    fileLink = data.find('a')['href']
    dataArray = data.find('a').contents  # dataArray looks something like this: ['230 KB .jpg']
    dataArray = dataArray[0].split(' ')

    conversionTable = {
        'KB': 0.001,
        'MB': 1.000,
        'GB': 1000.
    }
    return float(dataArray[0].replace(',', '')) * conversionTable[dataArray[1]], fileLink, dataArray[2]


def checkLimit(netSize, limit, fileSize):
    netSize += fileSize
    if netSize >= limit:
        print('Scraping capacity has been reached!')
        exitScript()
    return netSize


def ScrapeFromArtist(defaultURL, name, directory, limit, encode='utf-8'):
    name = urllib.parse.quote(name, encoding=encode)
    newName = urllib.parse.quote(findArtist(defaultURL, name), encoding=encode)
    url = joinPath(defaultURL, 'posts')

    print('*** Picking up links ***')
    hrefs = findAllHref(url, newName)
    print(str(len(hrefs)) + ' illustrations picked up!\n')

    netSize = 0.
    print('*** Saving illustrations **')
    for href in hrefs:
        soup = readURL(defaultURL + href)
        fileSize, fileLink, pathEnd = getFileData(soup)
        netSize = checkLimit(netSize, limit, fileSize)

        saveIMG(directory, newName, href, fileLink, pathEnd)
    return


def exitScript():
    print('\n\n*** Exiting Script Now! ***')
    time.sleep(5)
    sys.exit()
